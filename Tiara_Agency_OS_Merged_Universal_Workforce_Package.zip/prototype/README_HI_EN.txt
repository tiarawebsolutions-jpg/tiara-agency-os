TIARA AGENCY OS — UNIVERSAL WORKFORCE PROTOTYPE

WHAT THIS IS
A first no-paid-API prototype page for the existing Tiara Agency OS catalogue.
It routes a client task to a small set of relevant specialists by matching the
task against agent names, file paths and the actual text of agent instructions.
It then creates a work order, a ChatGPT handoff prompt, and the required report
sections:
- Completed by App
- Ready for ChatGPT
- Final Work Report

IMPORTANT
This is not an autonomous AI runtime. It does not itself execute code, create
apps, deploy products, or call AI models. Routing is local keyword scoring.
The next engineering phase is to add model-based planning and approved tools,
with explicit cost controls and human approval for external actions.

HOW TO TEST
1. Extract this ZIP.
2. Copy workforce.html into the same folder as the original Tiara Agency OS
   catalog.js (do not replace catalog.js or index.html).
3. Open workforce.html through the same hosting location as catalog.js.
4. Enter a sample task such as:
   "Build an Android expense tracking app with login, database, admin dashboard,
   and testing."
5. Tap "Analyse Task & Select Specialists".
6. Review the specialists, copy the Work Order or ChatGPT Handoff.

SAFETY
- Original index.html and catalog.js are not modified.
- No live GitHub files are changed by this package.
- No paid API key is required.
- The prototype only reads the catalogue; it does not change source instructions.
