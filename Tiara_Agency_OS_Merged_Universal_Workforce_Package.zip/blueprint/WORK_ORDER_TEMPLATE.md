# Agent Work Order

Task ID:
Client/project:
Master Manager:
Assigned specialist (exact catalog title):
Agent source path/ID:
Division:
Selection evidence:

## Objective
## Context and input files
## In scope
## Out of scope
## Constraints
## Required deliverable
## Acceptance criteria
## Dependencies and approvals
## Handoff destination
## Completion evidence
