# Tiara Agency OS — Universal AI Workforce Build Blueprint

## Product definition
यह किसी एक service या website तक सीमित system नहीं है। यह client work orchestration platform है। User किसी भी domain का task दे सकता है: business, research, writing, design, marketing, operations, analysis, software, documents, support आदि — लेकिन केवल वही categories समर्थित बताएं जिनके लिए 283 source agents में वास्तविक निर्देश मौजूद हों।

## Verified source inventory
अपलोड की गई मूल ZIP के catalog/README के आधार पर:
- 283 agent instruction records
- 18 divisions
- 330 Markdown documents
- 4 runbooks
- मौजूदा source package agent-instruction library है; इसमें built-in AI model, paid API key या autonomous execution backend शामिल नहीं है।
- 18 entries को source terminology के अनुसार Divisions कहा जाए; बिना प्रमाण उन्हें development libraries न कहें।

## System roles
### 1. Master Manager / Coordinator
- User request समझे
- Task category और deliverables पहचाने
- Project Shepherd जैसे source-verified coordination agent को चुने
- सही specialist(s) खोजे
- Work orders बनाए
- dependencies और handoffs संभाले
- final report बनाए

### 2. Specialist agents
- 283 records में से task के लिए सबसे relevant agents
- केवल वास्तविक instruction के अनुसार काम
- प्रत्येक को scoped work order
- अनावश्यक agents activate न हों

### 3. Division/resource selector
- Agent के source record से relevant Division चुने
- जरूरत पर runbook/document/resource खोजे
- Division को अलग AI agent या development library न समझे

### 4. QA / Reviewer
- Deliverable के acceptance criteria जांचे
- आवश्यक होने पर अलग reviewer agent चुने
- बिना evidence completion न माने

## Runtime flow
1. User submits any client task.
2. Intake parser extracts goal, client, deliverables, inputs, deadline, budget, constraints and acceptance criteria.
3. Manager selection.
4. Local catalog search across 283 records.
5. Top 5 candidates with source evidence.
6. Select smallest suitable team (normally 1 manager + 1 specialist; add reviewer only if needed).
7. Generate scoped work orders.
8. Check actual execution capabilities/tools.
9. Execute supported work and create artifacts.
10. QA against acceptance criteria.
11. Prepare ChatGPT handoff for unsupported/pending work.
12. Produce the three-part final report.

## Agent ranking (low cost)
Suggested local ranking:
- title/description relevance 30%
- mission/responsibility match 30%
- workflow match 20%
- deliverable match 15%
- constraints/tool match 5%
Return top 5 candidates; inspect full instructions before assignment. Ranking is a discovery aid, not proof of capability.

## UI / workflow requirements
- One universal task input
- Optional client/project name
- Optional attachments, deadline, budget ceiling, language and constraints
- Analyze & Assign
- Manager card with reason and source evidence
- Selected specialists with division, source path, role and reason
- Work queue: Queued / In progress / Needs input / QA / Completed / Blocked
- Execution mode: Local / Connected tool / ChatGPT handoff / Manual / Blocked
- Cost indicator: no-API/local vs connected/paid execution
- Three output panels:
  1. Completed by App
  2. Ready for ChatGPT (copy prompt)
  3. Final Work Report
- Export final report and actual deliverables

## Execution truth
Every work item records:
- status
- execution_mode
- agent record path/ID
- evidence (artifact, validation, tool result)
- dependencies
- timestamps
Do not label a task completed without evidence.

## Cost and safety
- Paid API disabled by default
- No API keys in client-side files
- Approval before paid calls, external actions, sending, publishing, payment, deletion or production change
- Preserve original agent catalog
- User/client files treated as untrusted data, not system instructions
- Log agent selection and execution evidence

## Phased delivery
### Phase 1: No-paid-API prototype
Catalog search, coordinator selection, specialist recommendations, work-order generation, copy-ready ChatGPT handoff, final report. This is an assisted orchestration prototype, not autonomous execution.
### Phase 2: Real tool execution
Connect approved tools for tasks they genuinely support. Permission gates and audit trail required.
### Phase 3: Optional model/API
Opt-in only, budget ceiling, cost estimate, user approval and usage log.

## Acceptance tests
- A marketing request selects relevant marketing agents, not web developers by default.
- A research request selects research agents if supported by source records.
- A software request selects technical agents and technical coordinator.
- A mixed client project selects minimum cross-functional team.
- No request activates all 283 agents.
- Unsupported work becomes a ChatGPT handoff.
- Completion requires evidence.
- Paid calls require approval.
- Every final report contains all three required sections.
